import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/common_app_bar.dart';
import 'package:happy_weds_vendors/utils/api_config.dart';

class SocialNetworkPage extends StatefulWidget {
  const SocialNetworkPage({super.key});

  @override
  State<SocialNetworkPage> createState() => _SocialNetworkPageState();
}

class _SocialNetworkPageState extends State<SocialNetworkPage> {
  final TextEditingController facebookController = TextEditingController();
  final TextEditingController instagramController = TextEditingController();
  final TextEditingController pinterestController = TextEditingController();
  final TextEditingController twitterController = TextEditingController();
  final TextEditingController websiteController = TextEditingController();
  final TextEditingController threadsController = TextEditingController();
  final TextEditingController youtubeController = TextEditingController();
  final TextEditingController linkedinController = TextEditingController();

  bool loading = false;
  bool saving = false;

  int? vendorId;
  String? token;

  @override
  void initState() {
    super.initState();
    _init();
  }

  // ================= INIT =================
  Future<void> _init() async {
    final prefs = await SharedPreferences.getInstance();
    vendorId = prefs.getInt('vendorId');
    token = prefs.getString('token');

    print("🔑 vendorId: $vendorId | token: $token");

    if (vendorId != null && token != null) {
      await _fetchLinksFromAPI(); // 🔥 ALWAYS FETCH FRESH
    }
  }

  // ================= FETCH FROM API =================
  Future<void> _fetchLinksFromAPI() async {
    setState(() => loading = true);

    try {
      final response = await http.get(
        Uri.parse("${ApiConfig.baseUrl}/vendor/$vendorId"),
        headers: {
          "Authorization": "Bearer $token",
        },
      );

      print("📩 GET response: ${response.statusCode}");
      print("📦 Body: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        setState(() {
          facebookController.text = data['facebook_link'] ?? '';
          instagramController.text = data['instagram_link'] ?? '';
          pinterestController.text = data['pinterest_link'] ?? '';
          twitterController.text = data['twitter_link'] ?? '';
          websiteController.text = data['website'] ?? '';

          threadsController.text = data['threads_link'] ?? '';
          youtubeController.text = data['youtube_link'] ?? '';
          linkedinController.text = data['linkedin_link'] ?? '';
        });

        // Optional: cache locally
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('facebook_link', facebookController.text);
        await prefs.setString('instagram_link', instagramController.text);
        await prefs.setString('pinterest_link', pinterestController.text);
        await prefs.setString('twitter_link', twitterController.text);
        await prefs.setString('website', websiteController.text);
        await prefs.setString('threads_link', threadsController.text);
        await prefs.setString('youtube_link', youtubeController.text);
        await prefs.setString('linkedin_link', linkedinController.text);


        print("✅ Fresh links loaded from API");
      } else {
        print("❌ Failed to fetch vendor data");
      }
    } catch (e) {
      print("❌ API Error: $e");
    }

    setState(() => loading = false);
  }

  // ================= SAVE LINKS =================
  Future<void> saveLinks() async {
    if (vendorId == null || token == null) return;

    setState(() => saving = true);

    final body = {
      "facebook_link": facebookController.text.trim(),
      "instagram_link": instagramController.text.trim(),
      "pinterest_link": pinterestController.text.trim(),
      "twitter_link": twitterController.text.trim(),
      "website": websiteController.text.trim(),

      "threads_link": threadsController.text.trim(),
      "youtube_link": youtubeController.text.trim(),
      "linkedin_link": linkedinController.text.trim(),
    };

    try {
      final response = await http.put(
        Uri.parse("${ApiConfig.baseUrl}/vendor/$vendorId"),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer $token",
        },
        body: jsonEncode(body),
      );

      print("📩 PUT response: ${response.statusCode}");
      print("📦 Body: ${response.body}");

      if (response.statusCode == 200 || response.statusCode == 201) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('facebook_link', body['facebook_link']!);
        await prefs.setString('instagram_link', body['instagram_link']!);
        await prefs.setString('pinterest_link', body['pinterest_link']!);
        await prefs.setString('twitter_link', body['twitter_link']!);
        await prefs.setString('website', body['website']!);

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Links saved successfully")),
        );

        print("✅ Links updated on server + local cache");
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to save links")),
        );
      }
    } catch (e) {
      print("❌ Save error: $e");
    }

    setState(() => saving = false);
  }

  // ================= UI =================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CommonAppBar(title: "Professional Links"),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
        // Edge to edge (targetSdk 36): the extra bottom keeps the last item
        // clear of the 3-button navigation bar.
        padding: EdgeInsets.fromLTRB(20, 20, 20,
            20 + MediaQuery.of(context).padding.bottom),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Add Your Professional Links",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 30),

            _socialField(
              label: "Facebook",
              hint: "https://www.facebook.com/username",
             // icon: Icons.facebook,
              imagePath: "assets/images/facebook.png",
              //color: const Color(0xFF1877F2),
              color: Colors.white,
              controller: facebookController,
            ),

            _socialField(
              label: "Instagram",
              hint: "https://www.instagram.com/username",
              imagePath: "assets/images/social.png",
              //color: const Color(0xFF00509D),// Instagram Pink
              // color: Color(0xFFE1306C),
              color: Colors.white,
              controller: instagramController,
            ),

            _socialField(
              label: "Pinterest",
              hint: "https://www.pinterest.com/username",
              // icon: Icons.push_pin,
              imagePath: "assets/images/pinterest.png",
             // color: const Color(0xFFE60023),
              color: Colors.white,
              controller: pinterestController,
            ),

            _socialField(
              label: "X(Twitter)",
              hint: "https://www.twitter.com/username",
              //icon: Icons.alternate_email,
              imagePath: "assets/images/twitter.png",
             // color: const Color(0xFF1DA1F2),
              color: Colors.white,
              controller: twitterController,
            ),

            _socialField(
              label: "Website",
              hint: "https://www.yourwebsite.com",
              //icon: Icons.web,
              imagePath: "assets/images/web.png",
              // color: const Color(0xFF4CAF50),
              color: Colors.white,
              controller: websiteController,
            ),

            _socialField(
              label: "Threads",
              hint: "https://www.threads.net/username",
              //icon: Icons.web,
              imagePath: "assets/images/threads.png",
              // color: const Color(0xFF4CAF50),
              color: Colors.white,
              controller: threadsController,
            ),

            _socialField(
              label: "Youtube",
              hint: "https://www.youtube.com/channel",
              //icon: Icons.web,
              imagePath: "assets/images/you.png",
              // color: const Color(0xFF4CAF50),
              color: Colors.white,
              controller: youtubeController,
            ),

            _socialField(
              label: "LinkedIn",
              hint: "https://www.linkedin.com/in/username",
              //icon: Icons.web,
              imagePath: "assets/images/linkedin.png",
              // color: const Color(0xFF4CAF50),
              color: Colors.white,
              controller: linkedinController,
            ),

            const SizedBox(height: 40),

            Center(
              child: ElevatedButton(
                onPressed: saving ? null : saveLinks,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00509D),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 30, vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: saving
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text(
                  "Save Links",
                  style:
                  TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ================= SOCIAL FIELD WIDGET =================

  Widget _socialField({
    required String label,
    required String hint,
    IconData? icon,
    String? imagePath,
    required Color color,
    required TextEditingController controller,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Center(
                child: imagePath != null
                    ? Image.asset(
                  imagePath,
                  width: 30,
                  height: 30,
                  fit: BoxFit.contain,
                )
                    : Icon(
                  icon,
                  color: Colors.white,
                  size: 26,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: controller,
                decoration: InputDecoration(
                  hintText: hint,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}
