import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class UnreadHelper {
  static Future<int> fetchAndStoreUnreadCount() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token') ?? prefs.getString('authToken');

    if (token == null || token.isEmpty) return 0;

    final archived = prefs.getStringList('archived_leads') ?? [];
    final opened = prefs.getStringList('read_leads') ?? [];

    final res = await http.get(
      Uri.parse('https://happywedz.com/api/inbox'),
      headers: {
        'Accept': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );

    if (res.statusCode != 200) return 0;

    final data = jsonDecode(res.body);
    final leads = data['inbox'] ?? data['data'] ?? [];

    int unread = 0;

    for (var l in leads) {
      final lead = l['request'] ?? l;
      final id = (lead['_id'] ?? lead['id']).toString();

      if (!opened.contains(id) && !archived.contains(id)) {
        unread++;
      }
    }

    await prefs.setInt('unread_leads_count', unread);
    return unread;
  }
}
