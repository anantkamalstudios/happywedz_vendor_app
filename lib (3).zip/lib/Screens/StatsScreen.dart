import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

class StatsPage extends StatefulWidget {
  const StatsPage({Key? key}) : super(key: key);

  @override
  State<StatsPage> createState() => _StatsPageState();
}

class _StatsPageState extends State<StatsPage>
    with SingleTickerProviderStateMixin {
  // ---------- Leads (existing) ----------
  String selectedRange = "Daily";
  bool isLoading = true;
  List<dynamic> apiRequests = [];
  String? token;
  DateTime? customStartDate;
  DateTime? customEndDate;
  DateTime? impressionStartDate;
  DateTime? impressionEndDate;
  int? vendorId;
  int visibleLeadCount = 0;
  int visibleImpressionCount = 0;
  int leadCount = 0;
  int viewsCount = 0;


  // final List<String> ranges = ["Daily", "Weekly", "Monthly"];
  final List<String> ranges = [
    "Daily",
    "Weekly",
    "Monthly",
    "Custom Range",
  ];

  List<String> leadTypes = [
    "This Week",
    "This Month",
    "Last Month",
    "Custom Range"
  ];
  List<String> selectedLeadTypes = [];

  List<String> dailyLabels = [];
  List<double> dailyValues = [];

  List<String> weeklyLabels = [];
  List<double> weeklyValues = [];

  List<String> monthlyLabels = [];
  List<double> monthlyValues = [];

  // animations (used for both sections)
  late AnimationController _controller;
  late Animation<double> _fadeAnim;
  late Animation<double> _slideAnim;

  List<String> get xLabels {
    if (selectedRange == "Daily") return dailyLabels;
    if (selectedRange == "Weekly") return weeklyLabels;
    return monthlyLabels;
  }

  List<double> get yValues {
    if (selectedRange == "Daily") return dailyValues;
    if (selectedRange == "Weekly") return weeklyValues;
    return monthlyValues;
  }

  // ---------- Profile Views (new, independent) ----------
  // independent selected range for profile views
  String profileViewsRange = "Daily";
  String impressionsRange = "Daily";

  List<dynamic> profileViews = [];

  List<String> pvDailyLabels = [];
  List<double> pvDailyValues = [];

  List<String> pvWeeklyLabels = [];
  List<double> pvWeeklyValues = [];

  List<String> pvMonthlyLabels = [];
  List<double> pvMonthlyValues = [];

  int profileViewsTotal = 0;

  List<String> get impressionXLabels {
    if (impressionsRange == "Daily") return pvDailyLabels;
    if (impressionsRange == "Weekly") return pvWeeklyLabels;
    return pvMonthlyLabels;
  }

  List<double> get impressionYValues {
    if (impressionsRange == "Daily") return pvDailyValues;
    if (impressionsRange == "Weekly") return pvWeeklyValues;
    return pvMonthlyValues;
  }


  List<double> get pvYValues {
    if (profileViewsRange == "Daily") return pvDailyValues;
    if (profileViewsRange == "Weekly") return pvWeeklyValues;
    return pvMonthlyValues;
  }


  @override
  void initState() {
    super.initState();
    _controller =
        AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _fadeAnim = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _slideAnim =
        Tween<double>(begin: 30, end: 0).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));

    fetchDashboardData();
    _saveCountsToPrefs(leadCount, viewsCount);

  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  /// Try to read vendorId from SharedPreferences, if not present try to decode from JWT token payload.
  int? _resolveVendorIdFromPrefsOrToken(SharedPreferences prefs, String? token) {
    final int? vid = prefs.getInt("vendor_id");
    if (vid != null) return vid;

    if (token == null) return null;
    try {
      final parts = token.split('.');
      if (parts.length < 2) return null;
      String payload = parts[1];

      // base64Url decode with padding fix
      String normalized = base64Url.normalize(payload);
      final Uint8List decoded = base64Url.decode(normalized);
      final Map<String, dynamic> map = jsonDecode(utf8.decode(decoded));
      // payload may contain id or vendor id; check common keys
      if (map.containsKey('id')) return (map['id'] as num).toInt();
      if (map.containsKey('vendorId')) return (map['vendorId'] as num).toInt();
      if (map.containsKey('vendor_id')) return (map['vendor_id'] as num).toInt();
    } catch (e) {
      print("⚠ Error decoding token for vendor id: $e");
    }
    return null;
  }

  Future<void> _openCustomRangePickerForProfileViews() async {
    final DateTime now = DateTime.now();

    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(now.year - 1),
      lastDate: now,
      initialDateRange: DateTimeRange(
        start: impressionStartDate ?? now.subtract(const Duration(days: 7)),
        end: impressionEndDate ?? now,
      ),
    );

    if (picked == null) return;

    impressionStartDate = picked.start;
    impressionEndDate = picked.end;

    _generateCustomRangeProfileViews(picked.start, picked.end);

    // setState(() {
    //   pvSelectedRange = "Daily"; // ⭐ Custom = Daily chart
    // });
    setState(() {
      impressionsRange = "Daily";
    });

    _controller.forward(from: 0);
  }


  Future<void> _openCustomRangePickerForImpressions() async {
    final DateTime now = DateTime.now();

    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(now.year - 1),
      lastDate: now,
      initialDateRange: DateTimeRange(
        start: impressionStartDate ?? now.subtract(const Duration(days: 7)),
        end: impressionEndDate ?? now,
      ),
    );

    if (picked == null) return;

    impressionStartDate = picked.start;
    impressionEndDate = picked.end;

    _generateCustomRangeImpressions(
      picked.start,
      picked.end,
    );

    _controller.forward(from: 0);
  }

  void _generateCustomRangeProfileViews(DateTime start, DateTime end) {
    pvDailyLabels.clear();
    pvDailyValues.clear();

    int total = 0;
    DateTime current = DateTime(start.year, start.month, start.day);

    while (!current.isAfter(end)) {
      int count = profileViews.where((v) {
        DateTime d = DateTime.parse(v["addedAt"]);
        return d.year == current.year &&
            d.month == current.month &&
            d.day == current.day;
      }).length;

      total += count;

      pvDailyLabels.add(DateFormat("dd MMM").format(current));
      pvDailyValues.add(count.toDouble());

      current = current.add(const Duration(days: 1));
    }

    visibleImpressionCount = total; // ⭐ top card sync
  }

  void _generateCustomRangeImpressions(DateTime start, DateTime end) {
    pvDailyLabels.clear();
    pvDailyValues.clear();

    int total = 0;
    DateTime current = DateTime(start.year, start.month, start.day);

    while (!current.isAfter(end)) {
      int count = profileViews.where((v) {
        DateTime d = DateTime.parse(v["addedAt"]);
        return d.year == current.year &&
            d.month == current.month &&
            d.day == current.day;
      }).length;

      total += count;

      pvDailyLabels.add(DateFormat("dd MMM").format(current));
      pvDailyValues.add(count.toDouble());

      current = current.add(const Duration(days: 1));
    }

    visibleImpressionCount = total;
  }


  Future<void> _openCustomRangePickerForLeads() async {
    final DateTime now = DateTime.now();

    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(now.year - 1),
      lastDate: now,
      initialDateRange: DateTimeRange(
        start: customStartDate ?? now.subtract(const Duration(days: 7)),
        end: customEndDate ?? now,
      ),
    );

    if (picked == null) return;

    customStartDate = picked.start;
    customEndDate = picked.end;

    _generateCustomRangeLeads(
      picked.start,
      picked.end,
    );

    _controller.forward(from: 0);
  }


  void _generateCustomRangeLeads(DateTime start, DateTime end) {
    dailyLabels.clear();
    dailyValues.clear();

    int total = 0;

    DateTime current = DateTime(start.year, start.month, start.day);

    while (!current.isAfter(end)) {
      String label = DateFormat("dd MMM").format(current);

      int count = apiRequests.where((req) {
        DateTime d = DateTime.parse(req["createdAt"]);
        return d.year == current.year &&
            d.month == current.month &&
            d.day == current.day;
      }).length;

      total += count;
      dailyLabels.add(label);
      dailyValues.add(count.toDouble());

      current = current.add(const Duration(days: 1));
    }

    visibleLeadCount = total;
  }


  Future<void> _saveCountsToPrefs(int leads, int views) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setInt('lead_count', leads);
    await prefs.setInt('views_count', views);
    print('✅ Counts saved -> Leads: $leads, Views: $views');
  }


  Future<void> fetchDashboardData() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      token = prefs.getString("token");
      vendorId = _resolveVendorIdFromPrefsOrToken(prefs, token);

      print("🟢 Starting dashboard fetch. token present: ${token != null}, vendorId: $vendorId");

      if (token == null) {
        print("⚠ Token not found");
        setState(() => isLoading = false);
        return;
      }

      if (vendorId == null) {
        print("⚠ vendor_id not found in prefs or token payload");
      }

      // ------------------------------------------------------------------
      // ✅ 1) LEADS API
      // ------------------------------------------------------------------
      final leadUrl = Uri.parse("https://happywedz.com/api/request-pricing/vendor/dashboard");
      final leadRes = await http.get(leadUrl, headers: {"Authorization": "Bearer $token"});
      print("✅ Recent Leads Status: ${leadRes.statusCode}");
      print("📡 Raw Lead Response: ${leadRes.body}");

      if (leadRes.statusCode == 200) {
        final data = jsonDecode(leadRes.body);
        apiRequests = data["requests"] ?? [];
        print("ℹ Loaded ${apiRequests.length} lead requests");
      } else {
        print("⚠ Lead Server Error: ${leadRes.statusCode}");
      }

      // ------------------------------------------------------------------
      // ✅ 2) PROFILE VIEWS TOTAL (Display count)
      // ------------------------------------------------------------------
      profileViewsTotal = 0;

      if (vendorId != null) {
        final pvTotalUrl = Uri.parse("https://happywedz.com/api/vendor/profile-views/$vendorId");
        print("📡 Fetching Profile Views Total → $pvTotalUrl");

        final pvTotalRes =
        await http.get(pvTotalUrl, headers: {"Authorization": "Bearer $token"});

        print("✅ Raw Profile Views Total Response Status: ${pvTotalRes.statusCode}");
        print("✅ Raw Body: ${pvTotalRes.body}");

        if (pvTotalRes.statusCode == 200) {
          final pData = jsonDecode(pvTotalRes.body);

          if (pData["success"] == true && pData["vendor"] != null) {
            final views = pData["vendor"]["profileViews"];
            profileViewsTotal = (views ?? 0).toInt();
            print("✅ Assigned profileViewsTotal → $profileViewsTotal");
          } else {
            print("⚠ Invalid structure in profile-views response");
          }
        } else {
          print("❌ ERROR → Profile Views Total statusCode = ${pvTotalRes.statusCode}");
        }
      }

      // ------------------------------------------------------------------
      // ✅ 3) IMPRESSIONS (wishlist users)
      // ------------------------------------------------------------------
      profileViews = [];
      int impressionCount = 0;

      if (vendorId != null) {
        final profileUrl =
        Uri.parse("https://happywedz.com/api/wishlist/vendor/stats/$vendorId");

        print("📡 Fetching Wishlist Stats (Impressions) → $profileUrl");

        final profileRes =
        await http.get(profileUrl, headers: {"Authorization": "Bearer $token"});

        print("✅ Raw Wishlist Response Status: ${profileRes.statusCode}");
        print("✅ Raw Body: ${profileRes.body}");

        if (profileRes.statusCode == 200) {
          final pData = jsonDecode(profileRes.body);

          if (pData["data"] != null && (pData["data"] as List).isNotEmpty) {
            final first = pData["data"][0];

            if (first != null && first["users"] != null) {
              profileViews = List<dynamic>.from(first["users"]);
            }
          }
        } else {
          print("⚠ Wishlist Server Error: ${profileRes.statusCode}");
        }
      }

      impressionCount = profileViews.length;
      print("✅ impressionCount = $impressionCount");

      // ------------------------------------------------------------------
      // ✅ STORE COUNTS TO PREFERENCES
      // ------------------------------------------------------------------
      await prefs.setInt("lead_count", apiRequests.length);
      await prefs.setInt("views_count", profileViewsTotal);
      await prefs.setInt("impression_count", impressionCount);

      await prefs.setInt("lead_count", leadCount);
      await prefs.setInt("views_count", viewsCount);

      print("✅ Saved lead_count = $leadCount");
      print("✅ Saved views_count = $viewsCount");


      setState(() {});

      print("✅ SAVED lead_count = ${apiRequests.length}");
      print("✅ SAVED views_count = $profileViewsTotal");
      print("✅ SAVED impression_count = $impressionCount");

      await prefs.setBool("stats_updated", true);

      bool updated = prefs.getBool("stats_updated") ?? false;
      if (updated) setState(() {});

      // ------------------------------------------------------------------
      // ✅ PROCESS STATS
      // ------------------------------------------------------------------
      generateDaily();
      generateWeekly();
      generateMonthly();
      generateProfileDaily();
      generateProfileWeekly();
      generateProfileMonthly();
    } catch (e) {
      print("⚠ Exception: $e");
    }

    setState(() {
      isLoading = false;
    });

    _controller.forward();
  }
  void generateDaily() {
    dailyLabels.clear();
    dailyValues.clear();

    List<DateTime> last7days =
    List.generate(7, (i) => DateTime.now().subtract(Duration(days: i)))
        .reversed
        .toList();

    int total = 0;

    for (var day in last7days) {
      String label = DateFormat("dd MMM").format(day);
      int count = apiRequests.where((req) {
        DateTime d = DateTime.parse(req["createdAt"]);
        return d.year == day.year &&
            d.month == day.month &&
            d.day == day.day;
      }).length;

      total += count;
      dailyLabels.add(label);
      dailyValues.add(count.toDouble());
    }

    visibleLeadCount = total;
  }

  void generateWeekly() {
    weeklyLabels.clear();
    weeklyValues.clear();

    DateTime now = DateTime.now();
    DateTime currentWeekStart =
    now.subtract(Duration(days: now.weekday - 1));

    int total = 0;

    for (int i = 0; i < 6; i++) {
      DateTime weekStart = currentWeekStart.subtract(Duration(days: 7 * i));
      DateTime weekEnd = weekStart.add(const Duration(days: 6));

      String label =
          "${DateFormat('MMM d').format(weekStart)}-${DateFormat('d').format(weekEnd)}";
      weeklyLabels.insert(0, label);

      int count = apiRequests.where((req) {
        DateTime d = DateTime.parse(req["createdAt"]);
        return (d.isAfter(weekStart) || d.isAtSameMomentAs(weekStart)) &&
            (d.isBefore(weekEnd) || d.isAtSameMomentAs(weekEnd));
      }).length;

      total += count;
      weeklyValues.insert(0, count.toDouble());
    }

    visibleLeadCount = total;
  }

  void generateMonthly() {
    monthlyLabels.clear();
    monthlyValues.clear();

    DateTime now = DateTime.now();
    int total = 0;

    for (int i = 5; i >= 0; i--) {
      DateTime monthDate = DateTime(now.year, now.month - i, 1);
      String label = DateFormat("MMM").format(monthDate);
      monthlyLabels.add(label);

      int count = apiRequests.where((req) {
        DateTime d = DateTime.parse(req["createdAt"]);
        return d.year == monthDate.year &&
            d.month == monthDate.month;
      }).length;

      total += count;
      monthlyValues.add(count.toDouble());
    }

    visibleLeadCount = total;
  }


  // ----------------- FILTER for leads (unchanged) -----------------
  void filterDataByLeadType() {
    DateTime now = DateTime.now();
    DateTime start = DateTime(now.year, now.month, now.day);
    DateTime end = now;

    if (selectedLeadTypes.contains("This Week")) {
      start = now.subtract(Duration(days: now.weekday - 1));
      end = start.add(const Duration(days: 6));
    } else if (selectedLeadTypes.contains("This Month")) {
      start = DateTime(now.year, now.month, 1);
      end = DateTime(now.year, now.month + 1, 0);
    } else if (selectedLeadTypes.contains("Last Month")) {
      DateTime lastMonthStart = (now.month == 1)
          ? DateTime(now.year - 1, 12, 1)
          : DateTime(now.year, now.month - 1, 1);
      DateTime lastMonthEnd =
      DateTime(lastMonthStart.year, lastMonthStart.month + 1, 0);
      start = lastMonthStart;
      end = lastMonthEnd;
      print("📅 Last Month Range (Leads): $start → $end");
    }

    List<dynamic> filtered = apiRequests.where((req) {
      DateTime created = DateTime.parse(req["createdAt"]);
      return (created.isAfter(start) || created.isAtSameMomentAs(start)) &&
          (created.isBefore(end) || created.isAtSameMomentAs(end));
    }).toList();

    if (selectedRange == "Daily") {
      generateDailyFrom(filtered);
    } else if (selectedRange == "Weekly") {
      generateWeeklyFrom(filtered);
    } else {
      generateMonthlyFrom(filtered);
    }

    setState(() {});
    _controller.forward(from: 0);
  }

  void generateDailyFrom(List<dynamic> filtered) {
    dailyLabels.clear();
    dailyValues.clear();

    List<DateTime> last7days =
    List.generate(7, (i) => DateTime.now().subtract(Duration(days: i))).reversed.toList();

    for (var day in last7days) {
      String label = DateFormat("dd MMM").format(day);
      int count = filtered.where((req) {
        DateTime d = DateTime.parse(req["createdAt"]);
        return d.year == day.year && d.month == day.month && d.day == day.day;
      }).length;
      dailyLabels.add(label);
      dailyValues.add(count.toDouble());
    }
  }

  void generateWeeklyFrom(List<dynamic> filtered) {
    weeklyLabels.clear();
    weeklyValues.clear();
    DateTime now = DateTime.now();
    DateTime currentWeekStart = now.subtract(Duration(days: now.weekday - 1));

    for (int i = 0; i < 6; i++) {
      DateTime weekStart = currentWeekStart.subtract(Duration(days: 7 * i));
      DateTime weekEnd = weekStart.add(const Duration(days: 6));
      String label =
          "${DateFormat('MMM d').format(weekStart)}-${DateFormat('d').format(weekEnd)}";
      weeklyLabels.insert(0, label);
      int count = filtered.where((req) {
        DateTime d = DateTime.parse(req["createdAt"]);
        return (d.isAfter(weekStart) || d.isAtSameMomentAs(weekStart)) &&
            (d.isBefore(weekEnd) || d.isAtSameMomentAs(weekEnd));
      }).length;
      weeklyValues.insert(0, count.toDouble());
    }
  }

  void generateMonthlyFrom(List<dynamic> filtered) {
    monthlyLabels.clear();
    monthlyValues.clear();
    DateTime now = DateTime.now();
    for (int i = 5; i >= 0; i--) {
      DateTime monthDate = DateTime(now.year, now.month - i, 1);
      String label = DateFormat("MMM").format(monthDate);
      monthlyLabels.add(label);
      int count = filtered.where((req) {
        DateTime d = DateTime.parse(req["createdAt"]);
        return d.year == monthDate.year && d.month == monthDate.month;
      }).length;
      monthlyValues.add(count.toDouble());
    }
  }

  void generateProfileDaily() {
    pvDailyLabels.clear();
    pvDailyValues.clear();

    int total = 0;

    List<DateTime> last7days =
    List.generate(7, (i) => DateTime.now().subtract(Duration(days: i)))
        .reversed
        .toList();

    for (var day in last7days) {
      int count = profileViews.where((v) {
        DateTime d = DateTime.parse(v["addedAt"]);
        return d.year == day.year &&
            d.month == day.month &&
            d.day == day.day;
      }).length;

      total += count;

      pvDailyLabels.add(DateFormat("dd MMM").format(day));
      pvDailyValues.add(count.toDouble());
    }

    visibleImpressionCount = total; // ⭐ important
  }

  void generateProfileWeekly() {
    pvWeeklyLabels.clear();
    pvWeeklyValues.clear();

    int total = 0;
    DateTime now = DateTime.now();
    DateTime currentWeekStart = now.subtract(Duration(days: now.weekday - 1));

    for (int i = 0; i < 6; i++) {
      DateTime weekStart = currentWeekStart.subtract(Duration(days: 7 * i));
      DateTime weekEnd = weekStart.add(const Duration(days: 6));

      int count = profileViews.where((v) {
        DateTime d = DateTime.parse(v["addedAt"]);
        return (d.isAfter(weekStart) || d.isAtSameMomentAs(weekStart)) &&
            (d.isBefore(weekEnd) || d.isAtSameMomentAs(weekEnd));
      }).length;

      total += count;

      pvWeeklyLabels.insert(
          0,
          "${DateFormat('MMM d').format(weekStart)}-${DateFormat('d').format(weekEnd)}");
      pvWeeklyValues.insert(0, count.toDouble());
    }

    visibleImpressionCount = total;
  }

  void generateProfileMonthly() {
    pvMonthlyLabels.clear();
    pvMonthlyValues.clear();

    int total = 0;
    DateTime now = DateTime.now();

    for (int i = 5; i >= 0; i--) {
      DateTime monthDate = DateTime(now.year, now.month - i, 1);

      int count = profileViews.where((v) {
        DateTime d = DateTime.parse(v["addedAt"]);
        return d.year == monthDate.year && d.month == monthDate.month;
      }).length;

      total += count;

      pvMonthlyLabels.add(DateFormat("MMM").format(monthDate));
      pvMonthlyValues.add(count.toDouble());
    }

    visibleImpressionCount = total;
  }

  // Profile views filter (works similarly if you want a bottom-sheet filter later)
  void filterProfileViewsByType(String type) {
    // placeholder in case you want separate leadTypes for profile views later
    // currently we don't use this, but left here for parity/extension
    if (type == "This Week") {
      profileViewsRange = "Weekly";
    } else if (type == "This Month") {
      profileViewsRange = "Monthly";
    }
    setState(() {});
  }
  // ----------------- UI -----------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(70),
        child: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Colors.transparent,
          elevation: 0,
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color(0xFF003F88), // French Blue
                  Color(0xFF00509D), // Steel Azure
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black26,
                  blurRadius: 6,
                  offset: Offset(0, 3),
                ),
              ],
            ),
            padding: const EdgeInsets.fromLTRB(20, 30, 16, 10),
            alignment: Alignment.bottomLeft,
            child: const Text(
              "Statistics",
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.3,
              ),
            ),
          ),
        ),
      ),

      body: isLoading
          ? const Center(
        child: CircularProgressIndicator(),
      ) :FadeTransition(
        opacity: _fadeAnim,
        child: SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, 0.1), end: Offset.zero)
              .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut)),
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 30,),
                  // ---------- Top Stats Cards ----------
                  _topStatsCards(),
                  const SizedBox(height: 30),
                  // ---------- Leads (unchanged UI) ----------
                  _sectionHeader("Leads"),
                  const SizedBox(height: 10),
                  //_rangeSelectorForLeads(),
                  _rangeDropdownForLeads(),

                  const SizedBox(height: 10),
                  _animatedChartForLeads(),

                  const SizedBox(height: 30),

                  // ---------- Profile Views (new section) ----------
                  _sectionHeader("Impressions"),
                  const SizedBox(height: 10),
                  _rangeDropdownForImpressions(),
                  const SizedBox(height: 10),
                  _animatedChartForProfileViews(),

                  const SizedBox(height: 30),

                  _sectionHeader("Profile Views"),
                  const SizedBox(height: 10),
                  _rangeDropdownForProfileViews(),
                  const SizedBox(height: 10),
                  _animatedChartForProfileViews2(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _sectionHeader(String title) => Text(title,
      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold));
  // ---------- Leads widgets (unchanged look/behaviour) ----------

  Widget _rangeDropdownForLeads() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(6),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: selectedRange,
              icon: const Icon(Icons.keyboard_arrow_down),
              items: ranges.map((range) {
                return DropdownMenuItem(
                  value: range,
                  child: Text(
                    range,
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                );
              }).toList(),

                onChanged: (value) async {
                  if (value == null) return;

                  if (value == "Custom Range") {
                    await _openCustomRangePickerForLeads();

                    setState(() {
                      selectedRange = "Daily"; // ⭐ MOST IMPORTANT
                    });
                  } else {
                    setState(() {
                      selectedRange = value;
                    });

                    if (value == "Daily") {
                      generateDaily();
                    } else if (value == "Weekly") {
                      generateWeekly();
                    } else if (value == "Monthly") {
                      generateMonthly();
                    }
                  }

                  _controller.forward(from: 0);
                }

            ),
          ),
        ),
      ],
    );
  }
  Widget _topStatsCards() {
    return Row(
      children: [
        Expanded(
          child: _statCard(
            title: "TOTAL LEADS",
            //value: apiRequests.length.toString(),
            value: visibleLeadCount.toString(),

            icon: Icons.group,
            iconBg: const Color(0xFFE8F5E9),
            iconColor: const Color(0xFF2E7D32),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _statCard(
            title: "PROFILE VIEWS",
            value: profileViewsTotal.toString(),
            icon: Icons.remove_red_eye,
            iconBg: const Color(0xFFE3F2FD),
            iconColor: const Color(0xFF1565C0),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _statCard(
            title: "IMPRESSIONS",
            // value: profileViews.length.toString(),
            value: visibleImpressionCount.toString(),

            icon: Icons.favorite,
            iconBg: const Color(0xFFFCE4EC),
            iconColor: const Color(0xFFC2185B),
          ),
        ),
      ],
    );
  }

  Widget _statCard({
    required String title,
    required String value,
    required IconData icon,
    required Color iconBg,
    required Color iconColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.black54,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: 42,
            width: 42,
            decoration: BoxDecoration(
              color: iconBg,
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: iconColor, size: 22),
          ),
        ],
      ),
    );
  }


  Widget _animatedChartForLeads() {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 700),
      transitionBuilder: (child, anim) =>
          FadeTransition(opacity: anim, child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
                .animate(anim),
            child: child,
          )),
      child: _chartContainer(xLabels, yValues, key: ValueKey("leads_$selectedRange")),
    );
  }

  // ---------- Profile Views (New third section) ----------
  Widget _rangeDropdownForProfileViews() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(6),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: profileViewsRange,
              icon: const Icon(Icons.keyboard_arrow_down),
              items: ranges.map((range) {
                return DropdownMenuItem(
                  value: range,
                  child: Text(
                    range,
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                );
              }).toList(),

                onChanged: (value) async {
                  if (value == null) return;

                  if (value == "Custom Range") {
                    await _openCustomRangePickerForProfileViews();
                  } else {
                    setState(() {
                      profileViewsRange = value;
                    });

                    if (value == "Daily") {
                      generateProfileDaily();
                    } else if (value == "Weekly") {
                      generateProfileWeekly();
                    } else if (value == "Monthly") {
                      generateProfileMonthly();
                    }

                    _controller.forward(from: 0);
                  }
                }

            ),
          ),
        ),
      ],
    );
  }


  Widget _animatedChartForProfileViews2() {
    List<String> labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    List<double> values = List.generate(labels.length, (_) => profileViewsTotal.toDouble());

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 700),
      transitionBuilder: (child, anim) =>
          FadeTransition(opacity: anim, child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
                .animate(anim),
            child: child,
          )),
      child: _chartContainer(labels, values, key: const ValueKey("profileViews")),
    );
  }

  // ---------- Profile Views widgets (new, independent) ----------
  Widget _rangeDropdownForImpressions() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(6),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
            //  value: pvSelectedRange,
                value: impressionsRange,
              icon: const Icon(Icons.keyboard_arrow_down),
              items: ranges.map((range) {
                return DropdownMenuItem(
                  value: range,
                  child: Text(
                    range,
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                );
              }).toList(),

                onChanged: (value) async {
                  if (value == null) return;

                  if (value == "Custom Range") {
                    await _openCustomRangePickerForImpressions();

                    setState(() {
                      impressionsRange = "Daily"; // ⭐ VERY IMPORTANT
                    });
                  } else {
                    setState(() {
                      impressionsRange = value;
                    });

                    if (value == "Daily") {
                      generateProfileDaily();
                    } else if (value == "Weekly") {
                      generateProfileWeekly();
                    } else if (value == "Monthly") {
                      generateProfileMonthly();
                    }
                  }
                  _controller.forward(from: 0);
                }
            ),
          ),
        ),
      ],
    );
  }


  Widget _animatedChartForProfileViews() {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 700),
      transitionBuilder: (child, anim) =>
          FadeTransition(opacity: anim, child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
                .animate(anim),
            child: child,
          )),
      child:_chartContainer(
        impressionXLabels,
        impressionYValues,
        key: ValueKey("impressions_$impressionsRange"),
      )
    );
  }

  // Generic chart container reused for both sections
  Widget _chartContainer(List<String> labels, List<double> values, {Key? key}) {
    return Container(
      key: key,
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(6),
      ),
      child: SizedBox(
        height: 260,
        child: LineChart(
          LineChartData(
            maxY: (values.isNotEmpty ? values.reduce((a, b) => a > b ? a : b) : 0) + 5,
            minY: 0,
            lineBarsData: [
              LineChartBarData(
                isCurved: true,
                curveSmoothness: 0.25,
                spots: List.generate(values.length, (i) => FlSpot(i.toDouble(), values[i])),
                color: const Color(0xFF4682B4),

                dotData: FlDotData(show: true),
                barWidth: 2.5,
                belowBarData: BarAreaData(
                  show: true,
                  gradient: LinearGradient(
                    colors: [
                      Color(0xFF4682B4).withOpacity(0.35), // top, slightly stronger
                      Color(0xFF4682B4).withOpacity(0.05), // bottom, very faint
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ],
            titlesData: FlTitlesData(
              bottomTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  interval: 1,
                  reservedSize: 60,
                  getTitlesWidget: (value, meta) {
                    int index = value.toInt();
                    if (index >= 0 && index < labels.length) {
                      return Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Transform.rotate(
                          angle: -0.7,
                          child: Text(labels[index], style: const TextStyle(fontSize: 11)),
                        ),
                      );
                    }
                    return const SizedBox();
                  },
                ),
              ),
              leftTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  reservedSize: 30,
                  getTitlesWidget: (value, meta) => Text(value.toInt().toString(), style: const TextStyle(fontSize: 10)),
                ),
              ),
              topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
              rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
            ),
            gridData: FlGridData(show: true, horizontalInterval: 5, drawVerticalLine: false, getDrawingHorizontalLine: (v) => FlLine(color: Colors.grey.shade300, strokeWidth: 0.8)),
            borderData: FlBorderData(show: false),
            lineTouchData: LineTouchData(
              handleBuiltInTouches: true,
              touchTooltipData: LineTouchTooltipData(getTooltipItems: (touchedSpots) {
                return touchedSpots.map((spot) {
                  final idx = spot.x.toInt();
                  final label = (idx >= 0 && idx < labels.length) ? labels[idx] : "";
                  return LineTooltipItem("$label\n${spot.y.toInt()}",
                      const TextStyle(color: Colors.black, fontWeight: FontWeight.bold));
                }).toList();
              }),
            ),
          ),
        ),
      ),
    );
  }

  // ---------- Lead type bottom sheet (unchanged) ----------
  void _openLeadTypePopup() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(15))),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateSheet) {
            return Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              height: MediaQuery.of(context).size.height * 0.55,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text("Select Lead Type", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                      InkWell(
                        onTap: () {
                          Navigator.pop(context);
                          filterDataByLeadType();
                        },
                        child: const Text("OK", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: const Color(0xFF00BCD4),
                        )),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const Divider(height: 1),
                  Expanded(
                    child: ListView.builder(
                      itemCount: leadTypes.length,
                      itemBuilder: (context, index) {
                        String type = leadTypes[index];
                        bool isSelected = selectedLeadTypes.contains(type);
                        return CheckboxListTile(
                          activeColor: const Color(0xFF00BCD4),

                          controlAffinity: ListTileControlAffinity.leading,
                          value: isSelected,
                          title: Text(type),
                          onChanged: (bool? val) {
                            setStateSheet(() {
                              selectedLeadTypes.clear();
                              if (val == true) selectedLeadTypes.add(type);
                            });
                            setState(() {});
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}