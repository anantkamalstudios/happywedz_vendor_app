import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'new_screens/leads_list_stats.dart';

class StatsPage extends StatefulWidget {
  const StatsPage({Key? key}) : super(key: key);

  @override
  State<StatsPage> createState() => _StatsPageState();
}

class _StatsPageState extends State<StatsPage>
    with SingleTickerProviderStateMixin {
  // ---------- Common Period ----------
  String selectedPeriod = "This Week";
  final List<String> periods = [
    "This Week",
    "This Month",
    "Last Month",
    "Custom Range",
  ];
  DateTime? customStartDate;
  DateTime? customEndDate;

  // ---------- Data ----------
  bool isLoading = true;
  List<dynamic> apiRequests = [];
  List<dynamic> impressionList = [];
  List<dynamic> profileViewsList = [];
  int profileViewsTotal = 0;

  String? token;
  int? vendorId;

  // Chart Data
  List<String> dailyLabels = [];
  List<double> dailyValues = [];
  List<String> impressionDailyLabels = [];
  List<double> impressionDailyValues = [];
  List<String> profileViewLabels = [];
  List<double> profileViewValues = [];

  int visibleLeadCount = 0;
  int visibleImpressionCount = 0;
  int visibleProfileViewCount = 0;

  // Animation
  late AnimationController _controller;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    _fadeAnim = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    fetchDashboardData();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  // Token se vendor ID extract
  int? _resolveVendorIdFromPrefsOrToken(SharedPreferences prefs, String? token) {
    final int? vid = prefs.getInt("vendor_id");
    if (vid != null) return vid;
    if (token == null) return null;
    try {
      final parts = token.split('.');
      if (parts.length < 2) return null;
      final payload = parts[1];
      final normalized = base64Url.normalize(payload);
      final decoded = base64Url.decode(normalized);
      final map = jsonDecode(utf8.decode(decoded));
      return (map['id'] ?? map['vendorId'] ?? map['vendor_id'])?.toInt();
    } catch (e) {
      print("Token decode error: $e");
    }
    return null;
  }

  // ==================== Custom Range Picker ====================
  Future<void> _openCustomRangePicker() async {
    final now = DateTime.now();
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(now.year - 5),
      lastDate: now,
      initialDateRange: customStartDate != null && customEndDate != null
          ? DateTimeRange(start: customStartDate!, end: customEndDate!)
          : null,
    );

    if (picked == null) return;

    customStartDate = picked.start;
    customEndDate = picked.end;

    setState(() {
      selectedPeriod = "Custom Range";
    });

    // Direct PDF generate & show
    await _generateAndShowPdf();
  }

  // ==================== PDF Generation & Preview ====================
  Future<void> _generateAndShowPdf() async {
    final pdf = pw.Document();

    Map<String, int> getCountByDate(List<dynamic> list, String dateKey) {
      final map = <String, int>{};
      for (var item in list) {
        final dateStr = item[dateKey];
        if (dateStr == null) continue;
        final date = DateTime.parse(dateStr);
        if (date.isBefore(customStartDate!) || date.isAfter(customEndDate!)) continue;

        final formatted = DateFormat("dd MMM yyyy").format(date);
        map[formatted] = (map[formatted] ?? 0) + 1;
      }
      return map;
    }

    final leadsData = getCountByDate(apiRequests, "createdAt");
    final impressionsData = getCountByDate(impressionList, "addedAt");
    final profileViewsData = getCountByDate(profileViewsList, "createdAt");

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(40),
        build: (context) => [
          pw.Center(
            child: pw.Text("Statistics Report",
                style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
          ),
          pw.SizedBox(height: 12),
          pw.Center(
            child: pw.Text(
              "${DateFormat("dd MMM yyyy").format(customStartDate!)} - ${DateFormat("dd MMM yyyy").format(customEndDate!)}",
              style: const pw.TextStyle(fontSize: 16),
            ),
          ),
          pw.SizedBox(height: 30),

          if (leadsData.isNotEmpty) ...[
            pw.Text("Leads", style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 8),
            pw.Table.fromTextArray(
              headers: ["Date", "Count"],
              data: leadsData.entries.map((e) => [e.key, e.value.toString()]).toList(),
              border: pw.TableBorder.all(),
              headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            ),
            pw.SizedBox(height: 25),
          ],

          if (impressionsData.isNotEmpty) ...[
            pw.Text("Impressions", style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 8),
            pw.Table.fromTextArray(
              headers: ["Date", "Count"],
              data: impressionsData.entries.map((e) => [e.key, e.value.toString()]).toList(),
              border: pw.TableBorder.all(),
              headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            ),
            pw.SizedBox(height: 25),
          ],

          if (profileViewsData.isNotEmpty) ...[
            pw.Text("Profile Views", style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 8),
            pw.Table.fromTextArray(
              headers: ["Date", "Count"],
              data: profileViewsData.entries.map((e) => [e.key, e.value.toString()]).toList(),
              border: pw.TableBorder.all(),
              headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            ),
          ],

          if (leadsData.isEmpty && impressionsData.isEmpty && profileViewsData.isEmpty)
            pw.Center(child: pw.Text("No data available in selected range")),
        ],
      ),
    );

    // Direct PDF preview (print/share option bhi aayega)
    await Printing.layoutPdf(onLayout: (_) => pdf.save());
  }

  // ==================== Chart Regeneration ====================
  void _regenerateAllCharts(String period) {
    _regenerateLeadsChart(period);
    _regenerateImpressionsChart(period);
    _regenerateProfileViewsChart(period);
    setState(() {});
  }

  void _regenerateLeadsChart(String period) {
    dailyLabels.clear();
    dailyValues.clear();
    final now = DateTime.now();
    late DateTime start, end;

    if (period == "This Week") {
      start = now.subtract(Duration(days: now.weekday - 1));
      end = start.add(const Duration(days: 6));
    } else if (period == "This Month") {
      start = DateTime(now.year, now.month, 1);
      end = DateTime(now.year, now.month + 1, 0);
    } else if (period == "Last Month") {
      start = now.month == 1
          ? DateTime(now.year - 1, 12, 1)
          : DateTime(now.year, now.month - 1, 1);
      end = now.month == 1
          ? DateTime(now.year - 1, 12, 31)
          : DateTime(now.year, now.month, 0);
    } else {
      return;
    }

    var current = DateTime(start.year, start.month, start.day);
    int total = 0;
    while (!current.isAfter(end)) {
      final label = period == "This Week"
          ? DateFormat("EEE").format(current)
          : DateFormat("dd MMM").format(current);

      final count = apiRequests.where((req) {
        final d = DateTime.parse(req["createdAt"]);
        return d.year == current.year && d.month == current.month && d.day == current.day;
      }).length;

      dailyLabels.add(label);
      dailyValues.add(count.toDouble());
      total += count;
      current = current.add(const Duration(days: 1));
    }
    visibleLeadCount = total;
  }

  void _regenerateImpressionsChart(String period) {
    impressionDailyLabels.clear();
    impressionDailyValues.clear();
    // Same logic as above...
    final now = DateTime.now();
    late DateTime start, end;

    if (period == "This Week") {
      start = now.subtract(Duration(days: now.weekday - 1));
      end = start.add(const Duration(days: 6));
    } else if (period == "This Month") {
      start = DateTime(now.year, now.month, 1);
      end = DateTime(now.year, now.month + 1, 0);
    } else if (period == "Last Month") {
      start = now.month == 1
          ? DateTime(now.year - 1, 12, 1)
          : DateTime(now.year, now.month - 1, 1);
      end = now.month == 1
          ? DateTime(now.year - 1, 12, 31)
          : DateTime(now.year, now.month, 0);
    } else {
      return;
    }

    var current = DateTime(start.year, start.month, start.day);
    int total = 0;
    while (!current.isAfter(end)) {
      final label = period == "This Week"
          ? DateFormat("EEE").format(current)
          : DateFormat("dd MMM").format(current);

      final count = impressionList.where((v) {
        final d = DateTime.parse(v["addedAt"]);
        return d.year == current.year && d.month == current.month && d.day == current.day;
      }).length;

      impressionDailyLabels.add(label);
      impressionDailyValues.add(count.toDouble());
      total += count;
      current = current.add(const Duration(days: 1));
    }
    visibleImpressionCount = total;
  }

  void _regenerateProfileViewsChart(String period) {
    profileViewLabels.clear();
    profileViewValues.clear();
    final now = DateTime.now();
    late DateTime start, end;

    if (period == "This Week") {
      start = now.subtract(Duration(days: now.weekday - 1));
      end = start.add(const Duration(days: 6));
    } else if (period == "This Month") {
      start = DateTime(now.year, now.month, 1);
      end = DateTime(now.year, now.month + 1, 0);
    } else if (period == "Last Month") {
      start = now.month == 1
          ? DateTime(now.year - 1, 12, 1)
          : DateTime(now.year, now.month - 1, 1);
      end = now.month == 1
          ? DateTime(now.year - 1, 12, 31)
          : DateTime(now.year, now.month, 0);
    } else {
      return;
    }

    var current = DateTime(start.year, start.month, start.day);
    int total = 0;
    while (!current.isAfter(end)) {
      final label = period == "This Week"
          ? DateFormat("EEE").format(current)
          : DateFormat("dd MMM").format(current);

      final count = profileViewsList.where((v) {
        final d = DateTime.parse(v["createdAt"]);
        return d.year == current.year && d.month == current.month && d.day == current.day;
      }).length;

      profileViewLabels.add(label);
      profileViewValues.add(count.toDouble());
      total += count;
      current = current.add(const Duration(days: 1));
    }
    visibleProfileViewCount = total;
  }

  // ==================== API Fetch ====================
  Future<void> fetchDashboardData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      token = prefs.getString("token");
      vendorId = _resolveVendorIdFromPrefsOrToken(prefs, token);

      if (token == null) {
        setState(() => isLoading = false);
        return;
      }

      final leadRes = await http.get(
        Uri.parse("https://happywedz.com/api/request-pricing/vendor/dashboard"),
        headers: {"Authorization": "Bearer $token"},
      );
      if (leadRes.statusCode == 200) {
        apiRequests = jsonDecode(leadRes.body)["requests"] ?? [];
      }

      if (vendorId != null) {
        final pvRes = await http.get(
          Uri.parse("https://happywedz.com/api/vendor/profile-views/$vendorId"),
          headers: {"Authorization": "Bearer $token"},
        );
        if (pvRes.statusCode == 200) {
          final data = jsonDecode(pvRes.body);
          if (data["success"] == true) {
            profileViewsTotal = (data["totalViews"] ?? 0);
            profileViewsList = List<dynamic>.from(data["views"] ?? []);
          }
        }

        final impRes = await http.get(
          Uri.parse("https://happywedz.com/api/wishlist/vendor/stats/$vendorId"),
          headers: {"Authorization": "Bearer $token"},
        );
        if (impRes.statusCode == 200) {
          final data = jsonDecode(impRes.body);
          if (data["data"] != null && (data["data"] as List).isNotEmpty) {
            impressionList = List<dynamic>.from(data["data"][0]["users"] ?? []);
          }
        }
      }

      await prefs.setInt("lead_count", apiRequests.length);
      await prefs.setInt("views_count", profileViewsTotal);
      await prefs.setInt("impression_count", impressionList.length);

      _regenerateAllCharts("This Week");
    } catch (e) {
      print("Error: $e");
    } finally {
      setState(() => isLoading = false);
      _controller.forward();
    }
  }

  // ==================== UI ====================
  @override
  Widget build(BuildContext context) {
    final bool isCustomRange = selectedPeriod == "Custom Range";

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(70),
        child: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Colors.transparent,
          elevation: 0,
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                  colors: [Color(0xFF003F88), Color(0xFF00509D)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight),
              boxShadow: [
                BoxShadow(color: Colors.black26, blurRadius: 6, offset: Offset(0, 3))
              ],
            ),
            padding: const EdgeInsets.fromLTRB(20, 30, 16, 10),
            alignment: Alignment.bottomLeft,
            child: const Text("Statistics",
                style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w700)),
          ),
        ),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : FadeTransition(
        opacity: _fadeAnim,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 30),
                _topStatsCards(),
                const SizedBox(height: 20),
                _sharedRangeDropdown(),
                const SizedBox(height: 25),

                if (!isCustomRange) ...[
                  _sectionHeader("Leads"),
                  const SizedBox(height: 10),
                  _animatedChartForLeads(),
                  const SizedBox(height: 30),

                  _sectionHeader("Impressions"),
                  const SizedBox(height: 10),
                  _animatedChartForImpressions(),
                  const SizedBox(height: 30),

                  _sectionHeader("Profile Views"),
                  const SizedBox(height: 10),
                  _animatedChartForProfileViews(),
                  const SizedBox(height: 20),
                ],

                // Custom Range mein kuch nahi dikhega yahan (PDF already open ho chuka hoga)
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _sharedRangeDropdown() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(6),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: selectedPeriod,
              icon: const Icon(Icons.keyboard_arrow_down),
              items: periods
                  .map((e) => DropdownMenuItem(
                value: e,
                child: Text(e, style: const TextStyle(fontWeight: FontWeight.w600)),
              ))
                  .toList(),
              onChanged: (value) async {
                if (value == null) return;
                if (value == "Custom Range") {
                  await _openCustomRangePicker();
                } else {
                  setState(() => selectedPeriod = value);
                  _regenerateAllCharts(value);
                  _controller.forward(from: 0);
                }
              },
            ),
          ),
        ),
      ],
    );
  }

  List<dynamic> _getFilteredLeads() {
    // Same as before...
    // (unchanged - for leads list screen)
    if (selectedPeriod == "Custom Range" && customStartDate != null && customEndDate != null) {
      return apiRequests.where((req) {
        DateTime d = DateTime.parse(req["createdAt"]);
        return !d.isBefore(customStartDate!) && !d.isAfter(customEndDate!);
      }).toList();
    }
    // ... rest same
    DateTime now = DateTime.now();
    late DateTime start, end;
    if (selectedPeriod == "This Week") {
      start = now.subtract(Duration(days: now.weekday - 1));
      end = start.add(const Duration(days: 6));
    } else if (selectedPeriod == "This Month") {
      start = DateTime(now.year, now.month, 1);
      end = DateTime(now.year, now.month + 1, 0);
    } else if (selectedPeriod == "Last Month") {
      start = now.month == 1 ? DateTime(now.year - 1, 12, 1) : DateTime(now.year, now.month - 1, 1);
      end = now.month == 1 ? DateTime(now.year - 1, 12, 31) : DateTime(now.year, now.month, 0);
    } else {
      return apiRequests;
    }
    return apiRequests.where((req) {
      DateTime d = DateTime.parse(req["createdAt"]);
      return !d.isBefore(start) && !d.isAfter(end);
    }).toList();
  }

  Widget _sectionHeader(String title) =>
      Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold));

  Widget _topStatsCards() {
    return Row(
      children: [
        Expanded(
          child: _statCard(
            title: "TOTAL LEADS",
            value: visibleLeadCount.toString(),
            icon: Icons.group,
            iconBg: const Color(0xFFE8F5E9),
            iconColor: const Color(0xFF2E7D32),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => LeadsListScreen(leads: _getFilteredLeads())),
              );
            },
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _statCard(
            title: "PROFILE VIEWS",
            value: visibleProfileViewCount.toString(),
            icon: Icons.remove_red_eye,
            iconBg: const Color(0xFFE3F2FD),
            iconColor: const Color(0xFF1565C0),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _statCard(
            title: "IMPRESSIONS",
            value: visibleImpressionCount.toString(),
            icon: Icons.favorite,
            iconBg: const Color(0xFFFCE4EC),
            iconColor: const Color(0xFFC2185B),
          ),
        ),
      ],
    );
  }

  Widget _statCard({
    required String title,
    required String value,
    required IconData icon,
    required Color iconBg,
    required Color iconColor,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey.shade300),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 4))
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(title, style: const TextStyle(fontSize: 12, color: Colors.black54, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
            Container(
              height: 42,
              width: 42,
              decoration: BoxDecoration(color: iconBg, shape: BoxShape.circle),
              child: Icon(icon, color: iconColor, size: 22),
            ),
          ],
        ),
      ),
    );
  }

  Widget _animatedChartForLeads() {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 700),
      child: _chartContainer(dailyLabels, dailyValues, key: ValueKey("leads_$selectedPeriod")),
    );
  }

  Widget _animatedChartForImpressions() {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 700),
      child: _chartContainer(impressionDailyLabels, impressionDailyValues,
          key: ValueKey("impressions_$selectedPeriod")),
    );
  }

  Widget _animatedChartForProfileViews() {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 700),
      child: _chartContainer(profileViewLabels, profileViewValues,
          key: ValueKey("profile_$selectedPeriod")),
    );
  }

  Widget _chartContainer(List<String> labels, List<double> values, {Key? key}) {
    const double pointWidth = 55;
    return Container(
      key: key,
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(6),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: SizedBox(
          width: labels.length * pointWidth,
          height: 260,
          child: LineChart(
            LineChartData(
              maxY: values.isEmpty ? 5 : values.reduce((a, b) => a > b ? a : b) + 5,
              minY: 0,
              lineBarsData: [
                LineChartBarData(
                  isCurved: true,
                  curveSmoothness: 0.25,
                  spots: List.generate(values.length, (i) => FlSpot(i.toDouble(), values[i])),
                  color: const Color(0xFF4682B4),
                  dotData: const FlDotData(show: true),
                  barWidth: 2.5,
                  belowBarData: BarAreaData(
                    show: true,
                    gradient: LinearGradient(
                      colors: [
                        const Color(0xFF4682B4).withOpacity(0.35),
                        const Color(0xFF4682B4).withOpacity(0.05),
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
              ],
              titlesData: FlTitlesData(
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    interval: 1,
                    reservedSize: 60,
                    getTitlesWidget: (value, meta) {
                      final index = value.toInt();
                      if (index >= 0 && index < labels.length) {
                        return Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Text(labels[index], style: const TextStyle(fontSize: 11)),
                        );
                      }
                      return const SizedBox();
                    },
                  ),
                ),
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 30,
                    getTitlesWidget: (v, m) => Text(v.toInt().toString(), style: const TextStyle(fontSize: 10)),
                  ),
                ),
                topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              ),
              gridData: FlGridData(
                show: true,
                horizontalInterval: 5,
                drawVerticalLine: false,
                getDrawingHorizontalLine: (v) => FlLine(color: Colors.grey.shade300, strokeWidth: 0.8),
              ),
              borderData: FlBorderData(show: false),
              lineTouchData: LineTouchData(
                handleBuiltInTouches: true,
                touchTooltipData: LineTouchTooltipData(
                  getTooltipItems: (spots) => spots.map((spot) {
                    final idx = spot.x.toInt();
                    final label = idx >= 0 && idx < labels.length ? labels[idx] : "";
                    return LineTooltipItem("$label\n${spot.y.toInt()}",
                        const TextStyle(color: Colors.black, fontWeight: FontWeight.bold));
                  }).toList(),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}